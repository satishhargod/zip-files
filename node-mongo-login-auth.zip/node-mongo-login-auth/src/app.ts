import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import authRoutes from './routes/authRoutes';
import path from 'path';
import errorHandler from './middleware/errorMiddleware';
import connectDB from './config/initDB';
dotenv.config();


const app = express();

// Call the function to connect to MongoDB
connectDB();

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware to parse the body
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Routes
app.use('/auth', authRoutes);

app.use(errorHandler);

// Connect to MongoDB
const mongoURI = process.env.MONGO_URI || '';


  app.listen(process.env.PORT, () => {
    console.log(`Server running on port ${process.env.PORT}`);
  });