export const responseFlag = {
  SUCCESS: 'success',
  ERROR: 'error',
};