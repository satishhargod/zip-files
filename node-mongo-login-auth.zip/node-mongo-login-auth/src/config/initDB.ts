import mongoose from 'mongoose';
import { DATABASE_URL } from '../config';

const connectDB = (): void => {
  if (!DATABASE_URL) {
    throw new Error('DATABASE_URL is not defined');
  }

  mongoose
    .connect(DATABASE_URL)
    .then(() => {
      console.log('Mongodb connected....');
    })
    .catch((err: Error) => console.log(err.message));

  mongoose.connection.on('connected', () => {
    // console.log('Mongoose connected to db...');
  });

  mongoose.connection.on('error', (err: Error) => {
    console.log(err.message);
  });

  mongoose.connection.on('disconnected', () => {
    console.log('Mongoose connection is disconnected...');
  });

  process.on('SIGINT', () => {
    mongoose.connection.close().then(() => {
      console.log(
        'Mongoose connection is disconnected due to app termination...'
      );
      process.exit(0);
    });
  });
};

export default connectDB;