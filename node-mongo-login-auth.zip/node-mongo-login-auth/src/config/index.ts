import { config } from 'dotenv';
config();
// config({ path: `.env.${process.env.NODE_ENV || 'development'}` });
export const {
  //#BASIC
  DATABASE_URL,
  JWT_SECRET,
} = process.env;