import { Router } from 'express';
import AuthController from '../controllers/authController';
import { validateRequest } from '../middleware/validationMiddleware';
import { registerValidation, loginValidation } from '../validation/authValidation';


const router = Router();
// Render the Register page
router.get('/register', (req, res) => {
    res.render('register');
  });
  
  // Render the Login page
  router.get('/login', (req, res) => {
    res.render('login');
  });
  
router.post('/register', validateRequest(registerValidation), AuthController.register);
router.post('/login', validateRequest(loginValidation), AuthController.login);

export default router;