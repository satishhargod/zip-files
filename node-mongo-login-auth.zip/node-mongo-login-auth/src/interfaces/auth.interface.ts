export interface LoginInterface {
    email: string;
    password: string;
  }

  export interface PasswordInterface {
    password: string;
  }