import { User } from '../models/user';
import AppError from '../utils/AppError';

class UserRepository {

  // Method to find a user by email
  async findUserByEmail(email: string) {
    try {
      const user = await User.findOne({ email });
      if (!user) {
        throw new AppError('User not found', 404);
      }
      return user;
    } catch (error) {
      throw new AppError('Database query failed', 500);
    }
  }

  // Method to create a new user
  async createUser(email: string, password: string) {
    try {
      const user = new User({ email, password });
      await user.save();
      return user;
    } catch (error) {
      throw new AppError('Error saving user to database', 500);
    }
  }
}

export default new UserRepository(); // Export an instance of the class