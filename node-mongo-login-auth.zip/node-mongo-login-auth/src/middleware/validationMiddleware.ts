import { Request, Response, NextFunction } from 'express';
import Joi from 'joi';

// Middleware for handling Joi validation
export const validateRequest = (schema: Joi.ObjectSchema) => {
    return (req: Request, res: Response, next: NextFunction) => {
      const { error } = schema.validate(req.body, { abortEarly: false }); // disable abortEarly to capture all errors
      if (error) {
        // Map all errors to a simple array of error messages
        const errorMessages = error.details.map((detail) => detail.message);
        return res.status(400).json({ errors: errorMessages });
      }
      next();
    };
  };