import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import userRepository from '../repositories/user.repository';
import AppError from '../utils/AppError';
import jwt from 'jsonwebtoken';
import { JWT_SECRET } from '../config';

class AuthController {
  // Registration method
  async register(req: Request, res: Response, next: NextFunction) {
    const { email, password } = req.body;

    try {
      // Check if user already exists
      const existingUser = await userRepository.findUserByEmail(email);
      if (existingUser) {
        return next(new AppError('User already exists', 400));
      }

      // Hash password and create user
      const hashedPassword = await bcrypt.hash(password, 10);
      const user = await userRepository.createUser(email, hashedPassword);

      res.status(201).json({ message: 'User registered successfully', user });
    } catch (error) {
      next(error); // Pass the error to global error handler
    }
  }

  // Login method
  async login(req: Request, res: Response, next: NextFunction) {
    const { email, password } = req.body;

    try {
      const user = await userRepository.findUserByEmail(email);
      if (!user) {
        return next(new AppError('Invalid credentials', 400));
      }

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return next(new AppError('Invalid credentials', 400));
      }
      const token = jwt.sign({ id: user._id }, JWT_SECRET?JWT_SECRET:'dummykey', { expiresIn: '1h' });
      res.json({ message: 'Login successful', token: token });
    } catch (error) {
      next(error); // Pass the error to global error handler
    }
  }
}

export default new AuthController(); // Export an instance of the class